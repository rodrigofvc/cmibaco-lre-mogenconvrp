Instances are the same as for the ConVRP.
Usage is described in "The Generalized Consistent Vehicle Routing Problem" by Kovacs, Golden, Hartl, and Parragh (2014)
